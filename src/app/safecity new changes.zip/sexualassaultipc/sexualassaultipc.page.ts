import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sexualassaultipc',
  templateUrl: './sexualassaultipc.page.html',
  styleUrls: ['./sexualassaultipc.page.scss'],
})
export class SexualassaultipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
