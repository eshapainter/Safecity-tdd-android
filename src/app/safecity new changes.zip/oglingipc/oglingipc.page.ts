import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oglingipc',
  templateUrl: './oglingipc.page.html',
  styleUrls: ['./oglingipc.page.scss'],
})
export class OglingipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
