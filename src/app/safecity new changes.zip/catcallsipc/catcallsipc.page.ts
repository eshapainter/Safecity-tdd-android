import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-catcallsipc',
  templateUrl: './catcallsipc.page.html',
  styleUrls: ['./catcallsipc.page.scss'],
})
export class CatcallsipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
