import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onlineipc',
  templateUrl: './onlineipc.page.html',
  styleUrls: ['./onlineipc.page.scss'],
})
export class OnlineipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
