import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indecentipc',
  templateUrl: './indecentipc.page.html',
  styleUrls: ['./indecentipc.page.scss'],
})
export class IndecentipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
