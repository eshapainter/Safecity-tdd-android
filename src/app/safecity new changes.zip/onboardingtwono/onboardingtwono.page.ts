import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboardingtwono',
  templateUrl: './onboardingtwono.page.html',
  styleUrls: ['./onboardingtwono.page.scss'],
})
export class OnboardingtwonoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
