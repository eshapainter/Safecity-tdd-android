import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-humanipc',
  templateUrl: './humanipc.page.html',
  styleUrls: ['./humanipc.page.scss'],
})
export class HumanipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
