import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chainsnachtingipc',
  templateUrl: './chainsnachtingipc.page.html',
  styleUrls: ['./chainsnachtingipc.page.scss'],
})
export class ChainsnachtingipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
