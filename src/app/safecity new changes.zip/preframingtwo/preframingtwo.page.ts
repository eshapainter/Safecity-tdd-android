import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { Router } from '@angular/router';
import { SharedService } from '../shared.service'
import { DomSanitizer } from '@angular/platform-browser';
import * as $ from 'jquery'
@Component({
  selector: 'app-preframingtwo',
  templateUrl: './preframingtwo.page.html',
  styleUrls: ['./preframingtwo.page.scss'],
})
export class PreframingtwoPage implements OnInit {
  buttonDisabled = true;
  error: boolean = false;
  data
  content
  hide = false
  constructor(private navController: NavController, private sharedservice: SharedService, private sanitizer: DomSanitizer, private router: Router) {

    var self = this;

    //this.isEstimate = false
    let data = new FormData();
    data.append('security_key', '8140c7e293aaa1c933b29b53a2a9140cf176dcfd');
    data.append('country_id', localStorage.getItem('Country_id'));
    data.append('client_id', localStorage.getItem('Client_id'));
    data.append('lang_id', localStorage.getItem('Lang_id'));
    data.append('type', 'consent');
    data.append('content_for', 'mobile');
    this.sharedservice.presentLoadingDefault()
    this.sharedservice.sharedPostRequest('faq/getClientResourceList', data).subscribe((rdata: any) => {
      console.log(rdata);
      this.data = rdata['data']

      this.sharedservice.loaderDismiss()
      console.log(this.data)
      this.content = this.data[0].content
      this.hide = true;
      $(".dynamic-success-link1").html(this.content);
      $(".checkerrors").hide()
      $(".dynamic-click").attr("disabled", "disabled");
      $(".dynamic-click").click(function (event) {
        event.preventDefault();
        self.addReport1()
        console.log('next')

      });

      $(".dynamic-privacy").click(function (event) {
        event.preventDefault();


        console.log('privacy');
        self.policy()

      });


      $("#estimate").click(function (event) {
        // event.preventDefault();
        //console.log($("input[name='hidechecked]").is(':checked'))
        // var isEstimate = $(this).is(":checked");

        if ($(this).is(":checked")) {
          console.log("Checkbox is checked.");
          $(".dynamic-click").removeAttr("disabled");
         // $(".checkerrors").hide()
        }
        else if ($(this).is(":not(:checked)")) {
          console.log("Checkbox is unchecked.");
          //$(".checkerrors").show();
          $(".dynamic-click").attr("disabled", "disabled");
        }
        // console.log(isEstimate)
        console.log('next', event)

      });

    }, error => {
      this.sharedservice.loaderDismiss()
    },()=>{
      console.log('complete')
      this.sharedservice.loaderDismiss()
    });
  }

  ngOnInit() {
  }

  // ***********************************Button unable disable***********************************
  ButtonEnableDisable(e: any) {
    // console.log(e.detail.checked);
    if (e.detail.checked == true) {
      // console.log("in")
      this.buttonDisabled = false;
      this.error = false;
    }
    else {
      this.buttonDisabled = true;
      this.error = true;

    }

  }


  // ***********************************Add Report***********************************
  // addReport1() 
  // {
  // this.navController.navigateForward(`reportfiledone`);
  // }

  addReport1() {
    this.navController.navigateForward(`primaryform`);
  }

  policy() {
    this.navController.navigateForward(`privacypolicy`);
  }
}
