import { Component, OnInit } from '@angular/core';
import {TranslateService} from '@ngx-translate/core';
import {SharedService} from '../shared.service'
import { FormBuilder, FormGroup, Validators, FormControl, ReactiveFormsModule } from '@angular/forms';
@Component({
  selector: 'app-languagemenu',
  templateUrl: './languagemenu.page.html',
  styleUrls: ['./languagemenu.page.scss'],
})
export class LanguagemenuPage implements OnInit {
  language_list
  public form: FormGroup;
  val
  constructor(public translate:TranslateService, public formBuilder: FormBuilder,private sharedservice : SharedService) { 
    
    //  this.form = formBuilder.group({
    //   lang: [this.val ]      
    // });
    this.getLanguageList()
    
  }

  ngOnInit() {
    setTimeout(()=>{
      this.val = localStorage.getItem('Lang_id')  
      console.log(this.val)
    },700);
  
  }

  getLanguageList()
  {
    let data = new FormData();
    this.sharedservice.presentLoadingDefault()
    data.append('security_key','07b337e9971f28d49c9c4b0449ea071131f4a3b6');
    this.sharedservice.sharedPostRequest('common_controller/languagesList',data).subscribe((rdata: any) => {
      console.log(rdata);
      this.language_list = rdata['data']
     }, error => {
       this.sharedservice.loaderDismiss()
    },()=>{
      this.sharedservice.loaderDismiss()
    });
  }

  selectLanguage(e)
  {
    console.log( e.detail.value)
   
  }

  changeLanguage(e)
  {
    console.log(e)
    if(e.detail.value == '1')
      {
        this.translate.setDefaultLang('en')
        this.translate.use('en')
        localStorage.setItem('language', 'en')  
        localStorage.setItem('Lang_id', e.detail.value)  
      }
     else if(e.detail.value == '42')
      {
        this.translate.setDefaultLang('hi')
        this.translate.use('hi')
        localStorage.setItem('language', 'hi')  
        localStorage.setItem('Lang_id', e.detail.value)  
      }
      else if(e.detail.value == '77')
      {
        this.translate.setDefaultLang('ml')
        this.translate.use('ml')
        localStorage.setItem('language', 'ml')  
        localStorage.setItem('Lang_id', e.detail.value)  
      }
      else if(e.detail.value == '76')
      {
        this.translate.setDefaultLang('ma')
        this.translate.use('ma')
        localStorage.setItem('language', 'ma')  
        localStorage.setItem('Lang_id', e.detail.value)  
      }
  }
}
