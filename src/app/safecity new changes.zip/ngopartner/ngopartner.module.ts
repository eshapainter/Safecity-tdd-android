import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { NgopartnerPageRoutingModule } from './ngopartner-routing.module';

import { NgopartnerPage } from './ngopartner.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    NgopartnerPageRoutingModule
  ],
  declarations: [NgopartnerPage]
})
export class NgopartnerPageModule {}
