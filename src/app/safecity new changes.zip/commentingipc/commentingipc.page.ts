import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commentingipc',
  templateUrl: './commentingipc.page.html',
  styleUrls: ['./commentingipc.page.scss'],
})
export class CommentingipcPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
